package com.example.zefirka;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    // Шаг 1: Объявляем ссылки на наши элементы экрана
    private TextView textViewTitle;
    private EditText editTextName;
    private Button buttonGreet;
    private TextView textViewResult;
    private EditText textAge;
    private Button buttonDelete;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Эта строка загружает XML-разметку на экран устройства.
        // До нее вызывать findViewById НЕЛЬЗЯ!
        setContentView(R.layout.activity_main);

        // Шаг 2: Находим каждый элемент по его ID из activity_main.xml
        textViewTitle = findViewById(R.id.textViewTitle);
        editTextName = findViewById(R.id.editTextName);
        buttonGreet = findViewById(R.id.buttonGreet);
        textViewResult = findViewById(R.id.textViewResult);
        textAge = findViewById(R.id.editTextAge);
        buttonDelete = findViewById(R.id.buttonDelete);

        // Шаг 3: Вешаем слушатель клика на кнопку
        buttonGreet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Считываем текст, который пользователь напечатал в поле ввода
                String enteredName = editTextName.getText().toString().trim();

                // Проверяем: не пустое ли поле?
                if (enteredName.isEmpty()) {
                    // Показываем всплывающее уведомление (Toast)
                    Toast.makeText(MainActivity.this, "Пожалуйста, введите имя!", Toast.LENGTH_SHORT).show();
                } else {
                    // Формируем приветствие и выводим его в TextView
                    String greeting = "Привет, " + enteredName + "! Рады тебя видеть.";
                    textViewResult.setText(greeting);

                    // Очищаем поле ввода для следующего раза
                    editTextName.setText("");
                }
            }
        });
    }
}